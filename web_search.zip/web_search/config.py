from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class LLMConfig(BaseModel):
    """Configuration for LLM"""
    model: str = Field("gpt-4o", description="LLM model to use")
    temperature: float = Field(0.2, description="Temperature for LLM generation")
    max_tokens: int = Field(1000, description="Maximum tokens for LLM generation")
    api_key: str = Field("", description="API key for LLM service")
    api_base: str = Field("", description="API base URL for LLM service")
    api_version: str = Field("", description="API version for LLM service")

class SearchAPIConfig(BaseModel):
    """Configuration for search API"""
    provider: str = Field("tavily", description="Search API provider (tavily, google, bing)")
    api_key: str = Field("", description="API key for search service")
    max_results: int = Field(7, description="Maximum number of results per query")
    include_domains: list = Field(default_factory=list, description="Domains to include in search")
    exclude_domains: list = Field(default_factory=list, description="Domains to exclude from search")

class ModerationConfig(BaseModel):
    """Configuration for content moderation"""
    enabled: bool = Field(True, description="Whether to enable content moderation")
    threshold: float = Field(0.8, description="Threshold for content moderation (0.0-1.0)")
    categories: list = Field(default_factory=list, description="Categories to moderate")

class WebSearchConfig(BaseModel):
    """Configuration for web search"""
    # General settings
    max_search_queries: int = Field(2, description="Maximum number of search queries to generate")
    max_sources: int = Field(4, description="Maximum number of sources to use")
    include_content: bool = Field(True, description="Whether to include full content in results")
    
    # API configurations
    llm: LLMConfig = Field(default_factory=LLMConfig, description="LLM configuration")
    search_api: SearchAPIConfig = Field(default_factory=SearchAPIConfig, description="Search API configuration")
    moderation: ModerationConfig = Field(default_factory=ModerationConfig, description="Moderation configuration")
    
    # Performance settings
    timeout: int = Field(30, description="Timeout for external API calls in seconds")
    max_retries: int = Field(3, description="Maximum number of retries for failed requests")
    
    # Content processing
    max_tokens_per_source: int = Field(2000, description="Maximum tokens per source")
    summarize_sources: bool = Field(True, description="Whether to summarize sources")
    
    def get_runnable_config(self) -> Dict[str, Any]:
        """
        Get configuration for LangGraph runnables
        
        Returns:
            Dict[str, Any]: Configuration for LangGraph runnables
        """
        # Helper function to convert config to dict safely
        def to_dict(obj):
            if hasattr(obj, "dict") and callable(getattr(obj, "dict")):
                return obj.dict()
            elif isinstance(obj, dict):
                return obj
            else:
                return {}
        
        return {
            "configurable": {
                "max_search_queries": self.max_search_queries,
                "max_sources": self.max_sources,
                "include_content": self.include_content,
                "llm": to_dict(self.llm),
                "search_api": to_dict(self.search_api),
                "moderation": to_dict(self.moderation),
                "timeout": self.timeout,
                "max_retries": self.max_retries,
                "max_tokens_per_source": self.max_tokens_per_source,
                "summarize_sources": self.summarize_sources
            }
        }
