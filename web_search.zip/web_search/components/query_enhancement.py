"""
Query Enhancement Component

This component enhances the user's search query using LLM to make it more effective for search engines.
"""

import os
import logging
import time
import datetime
from typing import Dict, Any
from langchain_core.runnables import RunnableConfig
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

# Import directly for testing compatibility
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from state import WebSearchState

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# System prompt for single query enhancement
QUERY_ENHANCEMENT_PROMPT = """
You are a search query enhancement assistant. Your task is to improve the user's search query to make it more effective
for search engines. The enhanced query should:

1. Be clear and specific
2. Include relevant keywords
3. Remove unnecessary words
4. Be formatted for optimal search engine results
5. Maintain the original intent of the query
6. Include appropriate time elements when the query implies recency

Current date: {current_date}

When the query contains time-sensitive terms like "latest", "recent", "new", "current", "today", "this year", etc., 
include specific time references in the enhanced query (e.g., "2025", "May 2025", etc.) to ensure fresh results.

Original query: {query}

Provide only the enhanced query with no explanations or additional text.
"""

# System prompt for multiple query generation
MULTIPLE_QUERY_PROMPT = """
You are a search query optimization expert. Your task is to generate {num_queries} different search queries based on the original query 
to ensure comprehensive coverage of the topic. Each query should:

1. Cover a different aspect or perspective of the original query
2. Be clear, specific, and optimized for search engines
3. Include relevant keywords for that specific aspect
4. Be formatted for optimal search engine results
5. Together, provide comprehensive coverage of the topic
6. Include appropriate time elements when the query implies recency

Current date: {current_date}

When the query contains time-sensitive terms like "latest", "recent", "new", "current", "today", "this year", etc., 
include specific time references in the enhanced queries (e.g., "2025", "May 2025", etc.) to ensure fresh results.
Make sure at least one query specifically focuses on the most recent information available if the original query implies recency.

Original query: {query}

Generate exactly {num_queries} different search queries, each on a new line. Provide only the queries with no explanations or additional text.
Ensure the queries are diverse enough to cover different aspects of the topic but all related to the original intent.
"""

def enhance_query(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Enhance the user query using LLM to make it more effective for search engines.
    Can generate multiple search queries based on configuration for better coverage.
    
    Args:
        state: Current state with user query
        config: Configuration for the function
        
    Returns:
        Updated state with enhanced query and optionally multiple search queries
    """
    # Get configuration
    configurable = config.get("configurable", {})
    llm_config = configurable.get("llm", {})
    max_search_queries = configurable.get("max_search_queries", 1)
    
    # Get original query
    query = state["query"]
    
    # Get current date for time-aware query enhancement
    current_date = datetime.datetime.now().strftime("%B %d, %Y")  # Format: May 17, 2025
    
    # Initialize LLM
    llm = AzureChatOpenAI(
        azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt4o"),
        api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
        api_version=os.getenv("OPENAI_API_VERSION", "2025-03-01-preview"),
        azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
        temperature=0.2  # Slightly creative for query enhancement
    )
    
    # Default values in case of failure
    enhanced_query = query
    search_queries = []
    
    # Retry mechanism
    max_retries = 3
    retry_delay = 2  # Initial delay in seconds
    
    try:
        # If we only need one query, use the simple enhancement
        if max_search_queries <= 1:
            # Format system prompt for single query
            system_prompt = QUERY_ENHANCEMENT_PROMPT.format(query=query, current_date=current_date)
            
            for attempt in range(max_retries):
                try:
                    # Call LLM to enhance the query
                    response = llm.invoke([
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=f"Enhance this search query: {query}")
                    ])
                    
                    # Extract the enhanced query from the response
                    enhanced_query = response.content.strip()
                    logger.info(f"Enhanced query: '{enhanced_query}'")
                    search_queries = [enhanced_query]  # Single query in the list
                    break  # Success, exit retry loop
                except Exception as e:
                    if "429" in str(e) and attempt < max_retries - 1:  # Rate limit error and not the last attempt
                        logger.warning(f"Rate limit exceeded. Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                    else:
                        # Re-raise if it's not a rate limit error or we've exhausted retries
                        raise
        else:
            # Format system prompt for multiple queries
            system_prompt = MULTIPLE_QUERY_PROMPT.format(query=query, num_queries=max_search_queries, current_date=current_date)
            
            for attempt in range(max_retries):
                try:
                    # Call LLM to generate multiple queries
                    response = llm.invoke([
                        SystemMessage(content=system_prompt),
                        HumanMessage(content=f"Generate {max_search_queries} diverse search queries based on: {query}")
                    ])
                    
                    # Extract the multiple queries from the response
                    query_lines = [q.strip() for q in response.content.strip().split('\n') if q.strip()]
                    
                    # Ensure we have the right number of queries
                    if len(query_lines) > max_search_queries:
                        query_lines = query_lines[:max_search_queries]
                    elif len(query_lines) < max_search_queries:
                        # Fill with enhanced versions of the original if we don't have enough
                        while len(query_lines) < max_search_queries:
                            query_lines.append(query)
                    
                    # Set the first query as the primary enhanced query
                    enhanced_query = query_lines[0]
                    search_queries = query_lines
                    
                    logger.info(f"Generated {len(search_queries)} search queries for better coverage:")
                    for i, q in enumerate(search_queries):
                        logger.info(f"  Query {i+1}: {q}")
                    
                    break  # Success, exit retry loop
                except Exception as e:
                    if "429" in str(e) and attempt < max_retries - 1:  # Rate limit error and not the last attempt
                        logger.warning(f"Rate limit exceeded. Retrying in {retry_delay} seconds...")
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                    else:
                        # Re-raise if it's not a rate limit error or we've exhausted retries
                        raise
    except Exception as e:
        # If enhancement fails, default to original query
        logger.error(f"Query enhancement failed: {str(e)}")
        enhanced_query = query  # Use original query as fallback
        search_queries = [query]  # Single original query in the list
    
    # Return updated state with enhanced query and search queries
    return {
        "enhanced_query": enhanced_query,
        "search_queries": search_queries
    }
