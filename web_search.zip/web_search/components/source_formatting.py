"""
Source Formatting Component

This component formats the sources used in the response.
"""

from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig

from state import WebSearchState

def format_sources(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Format the sources used in the response.
    
    Args:
        state: Current state with response and extracted content
        config: Configuration for the function
        
    Returns:
        Updated state with formatted sources
    """
    # Get extracted content
    extracted_content = state["extracted_content"]
    
    # Format sources
    sources = []
    for result in extracted_content:
        source = {
            "title": result["title"],
            "url": result["url"],
            "content": result.get("content", "")
        }
        sources.append(source)
    
    # Return updated state
    return {"sources": sources}
