"""
Content Moderation Component

This component checks if the user query contains inappropriate content.
"""

import os
import logging
import time
from typing import Dict, Any, List, Optional
from langchain_core.runnables import RunnableConfig
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
import requests

# Import directly for testing compatibility
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from state import WebSearchState

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# System prompt for content moderation
MODERATION_PROMPT = """
You are a content moderation assistant responsible for identifying and flagging inappropriate search queries.

Your task is to evaluate if the given query contains any of the following types of inappropriate content:

1. Hate speech: Content that promotes hatred, discrimination, or violence against individuals or groups based on attributes like race, ethnicity, gender, religion, sexual orientation, or disability.

2. Violence: Content that glorifies, incites, or depicts graphic violence, torture, or harm to individuals or animals.

3. Sexual content: Explicit sexual content, pornography, or inappropriate sexual references.

4. Illegal activities: Content that promotes, facilitates, or provides instructions for illegal activities such as drug manufacturing, hacking, fraud, or terrorism.

5. Personal information: Requests for private personal information about specific individuals that could be used for doxxing, stalking, or harassment.

6. Harmful instructions: Content that provides instructions on how to harm oneself or others, including suicide methods, self-harm techniques, or how to create dangerous devices.

7. Malware/hacking: Requests for malicious software, hacking tools, or instructions for unauthorized system access.

8. Child exploitation: Any content related to child sexual abuse material or exploitation of minors.

Query to evaluate: {query}

Respond with a structured output containing:
- is_safe: Boolean indicating if the query is safe (true) or unsafe (false)
- categories: List of categories that apply if unsafe (empty list if safe)
- reason: Brief explanation of why the query is considered unsafe (empty string if safe)

Be thorough but fair in your evaluation. If the query is ambiguous but could reasonably be interpreted as a legitimate search, consider it safe.
"""

def moderate_query(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Moderate user query for inappropriate content.
    
    Args:
        state: Current state with user query
        config: Configuration for the function
        
    Returns:
        Updated state with moderation result
    """
    # Get configuration
    configurable = config.get("configurable", {})
    moderation_config = configurable.get("moderation", {})
    llm_config = configurable.get("llm", {})
    
    # Skip moderation if disabled
    if not moderation_config.get("enabled", True):
        return {"moderation_result": {"is_safe": True, "categories": [], "reason": "Moderation disabled"}}
    
    # Get query
    query = state["query"]
    
    # Get threshold for moderation
    threshold = moderation_config.get("threshold", 0.8)
    
    try:
        # Initialize LLM with structured output
        from pydantic import BaseModel, Field
        from typing import List
        
        class ModerationResult(BaseModel):
            is_safe: bool = Field(description="Whether the query is safe or not")
            categories: List[str] = Field(description="Categories of inappropriate content detected")
            reason: str = Field(description="Explanation for why the query is unsafe (if applicable)")
        
        # Initialize Azure OpenAI client
        llm = AzureChatOpenAI(
            azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt4o"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
            api_version=os.getenv("OPENAI_API_VERSION", "2025-03-01-preview"),
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            temperature=0  # Use 0 for deterministic results
        )
        
        # Use structured output with function_calling method for consistent results
        structured_llm = llm.with_structured_output(ModerationResult, method="function_calling")
        
        # Format system prompt
        system_prompt = MODERATION_PROMPT.format(query=query)
        
        # Call LLM for moderation with retry logic for rate limiting
        max_retries = 3
        retry_delay = 2  # Initial delay in seconds
        
        for attempt in range(max_retries):
            try:
                result = structured_llm.invoke([
                    SystemMessage(content=system_prompt),
                    HumanMessage(content=f"Evaluate this query: {query}")
                ])
                break  # Success, exit retry loop
            except Exception as e:
                if "429" in str(e) and attempt < max_retries - 1:  # Rate limit error and not the last attempt
                    logging.warning(f"Rate limit exceeded. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    # Re-raise if it's not a rate limit error or we've exhausted retries
                    raise
        
        # Convert to dictionary
        moderation_result = {
            "is_safe": result.is_safe,
            "categories": result.categories,
            "reason": result.reason
        }
        
        # Log moderation result
        import logging
        logging.info(f"Moderation result for query '{query}': {moderation_result}")
        
    except Exception as e:
        # If moderation fails, default to safe to avoid blocking legitimate queries
        import logging
        logging.error(f"Moderation failed: {str(e)}")
        moderation_result = {
            "is_safe": True,
            "categories": [],
            "reason": f"Moderation error: {str(e)}"
        }
    
    # Return updated state
    return {"moderation_result": moderation_result}
