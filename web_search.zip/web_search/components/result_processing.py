"""
Result Processing Component

This component processes search results, removing duplicates and ranking by relevance.
"""

from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig

from state import WebSearchState, SearchResult

def process_results(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Process search results, removing duplicates and ranking by relevance.
    
    Args:
        state: Current state with search results
        config: Configuration for the function
        
    Returns:
        Updated state with processed results
    """
    # Get configuration
    configurable = config.get("configurable", {})
    max_sources = configurable.get("max_sources", 4)  # Updated default to match config
    
    # Get search results - already deduplicated and sorted by search_execution
    search_results = state["search_results"]
    
    # No need to deduplicate or sort again, as this is now handled by search_execution
    # Just use the results as they are and convert to dictionaries for state
    processed_results = [
        {
            "title": result.title,
            "url": result.url,
            "content": result.content,
            "raw_content": result.raw_content,
            "metadata": result.metadata
        }
        for result in search_results
    ]
    
    # Return updated state
    return {"processed_results": processed_results}
