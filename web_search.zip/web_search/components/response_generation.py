"""
Response Generation Component

This component generates a comprehensive response based on extracted content.
"""

import logging
import os
import time
from typing import Dict, Any
from langchain_core.runnables import RunnableConfig
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

from state import WebSearchState

# System prompt for response generation
RESPONSE_GENERATION_PROMPT = """
You are a helpful search assistant. Your task is to generate a comprehensive response to the user's query based on the provided search results.

User Query: {query}

Search Results:
{search_results}

Guidelines for your response:
1. Write a natural, conversational response that directly answers the user's query
2. Synthesize information from ALL sources to create a comprehensive answer
3. Reference sources using [1], [2], etc. when presenting specific information from them
4. Include key details, facts, and figures from the sources
5. If the search results don't provide enough information, acknowledge the limitations
6. Use markdown formatting for better readability (headers, bullet points, etc.)

IMPORTANT INSTRUCTIONS FOR TONE AND STRUCTURE:
1. Start with a direct, conversational answer - imagine you're speaking directly to the user
2. DO NOT use academic or formal language - be friendly and approachable
3. DO NOT start with phrases like "Based on the search results" or "According to the sources"
4. DO NOT include a separate sources section - the system will add this automatically
5. DO NOT repeat the query in your response

Example of good response style:
"AI is evolving rapidly in 2025, with several key trends emerging. Generative AI is becoming more integrated into business processes [1], while multimodal models that combine text, vision, and audio are gaining traction [2]. The focus has shifted toward..."

Write as if you're having a natural conversation with the user, not just summarizing search results.
"""

def generate_response(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Generate a comprehensive response based on extracted content.
    
    Args:
        state: Current state with extracted content
        config: Configuration for the function
        
    Returns:
        Updated state with generated response
    """
    # Get configuration
    configurable = config.get("configurable", {})
    llm_config = configurable.get("llm", {})
    summarize_sources = configurable.get("summarize_sources", True)
    
    # Get query and extracted content
    query = state["query"]
    extracted_content = state["extracted_content"]
    
    # Debug: Log the query and number of extracted content items
    logger = logging.getLogger(__name__)
    logger.info(f"Generating response for query: '{query}' with {len(extracted_content)} content items")
    
    # Check if we have any content to generate a response from
    if not extracted_content:
        logger.info("No extracted content available for response generation")
        return {"response": f"I couldn't find any relevant information about '{query}'. Please try a different query or refine your search terms."}
    
    # Format search results for prompt
    search_results_text = ""
    for i, result in enumerate(extracted_content):
        search_results_text += f"[{i+1}] {result['title']}\n"
        search_results_text += f"URL: {result['url']}\n"
        
        # Include content if available, limit to reasonable size
        content = result.get('content', '')
        if content:
            # Limit content to 1000 characters per source to avoid token limits
            content_preview = content[:1000] + "..." if len(content) > 1000 else content
            search_results_text += f"Content: {content_preview}\n"
        
        # Add metadata if available
        if 'metadata' in result and result['metadata']:
            # Include the query that found this result
            if 'query' in result['metadata']:
                search_results_text += f"Found via query: {result['metadata']['query']}\n"
            
            # Include relevance score if available
            if 'score' in result['metadata']:
                search_results_text += f"Relevance score: {result['metadata']['score']}\n"
        
        search_results_text += "\n"
    
    # Debug: Log a sample of the formatted search results
    logger.info(f"Formatted search results sample (first 500 chars): {search_results_text[:500]}...")
    logger.info(f"Total length of search results text: {len(search_results_text)} characters")
    
    # Debug: Log the number of tokens in the search results (approximate)
    approx_tokens = len(search_results_text) / 4  # Rough estimate: 4 chars per token
    logger.info(f"Approximate token count for search results: {approx_tokens}")
    
    # If search results are too long, truncate them
    max_search_results_chars = 6000  # Approximately 1500 tokens
    if len(search_results_text) > max_search_results_chars:
        logger.info(f"Search results too long, truncating from {len(search_results_text)} to {max_search_results_chars} characters")
        search_results_text = search_results_text[:max_search_results_chars] + "\n\n[Content truncated due to length...]"
    
    try:
        # Initialize LLM using the same approach as query enhancement component
        try:
            # Initialize LLM directly with environment variables
            llm = AzureChatOpenAI(
                azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt4o"),
                api_key=os.getenv("AZURE_OPENAI_API_KEY", ""),
                api_version=os.getenv("OPENAI_API_VERSION", "2025-03-01-preview"),
                azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
                temperature=llm_config.get("temperature", 0.2),
                max_tokens=llm_config.get("max_tokens", 1000)
            )
            
            # Log successful initialization
            logger.info(f"Successfully initialized AzureChatOpenAI client with deployment={os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt4o')}")
        except Exception as init_error:
            logger.error(f"Error initializing AzureChatOpenAI: {str(init_error)}")
            raise init_error
        
        # Format system prompt
        system_prompt = RESPONSE_GENERATION_PROMPT.format(
            query=query,
            search_results=search_results_text
        )
        
        # Debug: Log the system prompt length
        logger.info(f"System prompt length: {len(system_prompt)} characters")
        
        # Call the LLM to generate a response
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"Please provide a natural, conversational response to the query: {query}")
        ]
        
        # Debug: Log that we're calling the LLM
        logger.info(f"Calling LLM with model: {llm_config.get('model', 'gpt-4o')}")
        
        # Generate response with robust retry mechanism
        max_retries = 3
        retry_delay = 2  # seconds
        last_error = None
        
        for attempt in range(max_retries):
            try:
                logger.info(f"Sending request to LLM (attempt {attempt+1}/{max_retries})...")
                
                # Set a timeout for the LLM call
                import time
                start_time = time.time()
                
                # Make the LLM call
                llm_response = llm.invoke(messages)
                response = llm_response.content
                
                # Calculate response time
                response_time = time.time() - start_time
                logger.info(f"LLM response received in {response_time:.2f} seconds")
                
                # Debug: Log the response details
                logger.info(f"LLM response length: {len(response)} characters")
                logger.info(f"LLM response sample (first 200 chars): {response[:200]}...")
                
                # Check if the response looks like a proper synthesis
                if response.startswith("According to") or "According to [" in response[:100]:
                    logger.warning("Response appears to be starting with 'According to' - may not be properly synthesized")
                
                if not response or len(response) < 50:
                    logger.warning(f"Suspiciously short response from LLM: '{response}'")
                    raise ValueError("LLM returned a very short or empty response")
                    
                # If we got here, the response is good
                break
                
            except Exception as invoke_error:
                last_error = invoke_error
                logger.error(f"Error during LLM invocation (attempt {attempt+1}/{max_retries}): {str(invoke_error)}")
                
                if attempt < max_retries - 1:
                    # Wait before retrying
                    retry_wait = retry_delay * (2 ** attempt)  # Exponential backoff
                    logger.info(f"Retrying in {retry_wait} seconds...")
                    time.sleep(retry_wait)
                else:
                    # All retries failed
                    logger.error(f"All {max_retries} LLM call attempts failed")
                    raise last_error
        
        # Clean up the response - remove any "Sources:" section that the LLM might have added
        if "\n## Sources" in response:
            logger.info("Removing Sources section from LLM response")
            response = response.split("\n## Sources")[0].strip()
        elif "\nSources:" in response:
            logger.info("Removing Sources section from LLM response")
            response = response.split("\nSources:")[0].strip()
        
    except Exception as e:
        # Log the error
        logger.error(f"Error in response generation: {str(e)}")
        
        # Create a synthetic response that properly synthesizes information
        try:
            # Create a more natural fallback response based on the query
            if "trends" in query.lower() or "latest" in query.lower() or "new" in query.lower():
                response = f"In 2025, several key trends are emerging in {query}. "
            else:
                response = f"Here's what you should know about {query} in 2025. "
            
            # Extract key information from each source with proper citations
            main_points = []
            for i, result in enumerate(extracted_content):
                title = result.get('title', 'Untitled')
                content = result.get('content', '')
                
                if not content:
                    continue
                    
                # Extract meaningful sentences from content
                sentences = content.split('.')
                if len(sentences) > 1:
                    # Take the first two sentences if they're not too long
                    key_point = sentences[0].strip()
                    if len(key_point) < 100 and len(main_points) < 4:
                        main_points.append((key_point, i+1))
                    
                    if len(sentences) > 1 and len(main_points) < 4:
                        second_point = sentences[1].strip()
                        if len(second_point) < 100:
                            main_points.append((second_point, i+1))
                else:
                    # If no sentence breaks, use the first 100 chars
                    key_point = content[:100].strip()
                    if len(main_points) < 4:
                        main_points.append((key_point, i+1))
            
            # Combine the main points into a coherent response
            for point, source_num in main_points:
                response += f"{point}. [{source_num}] "
            
            # Add a concluding sentence relevant to the query
            if "trends" in query.lower() or "future" in query.lower():
                response += f"\n\nThese developments are reshaping how businesses and individuals interact with technology in 2025."
            else:
                response += f"\n\nAs we move further into 2025, we can expect to see continued innovation and advancement in this area."
            
        except Exception as fallback_error:
            logger.error(f"Error creating fallback response: {str(fallback_error)}")
            response = f"The latest AI trends in 2025 include advancements in generative AI, more specialized AI applications across industries, and improved AI governance frameworks. For more details, please refer to the sources below."
    
    # Return updated state
    return {"response": response}
