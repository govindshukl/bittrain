"""
Search Execution Component

This component executes a search for a query using the configured search API.
"""

import os
import logging
import time
from typing import Dict, Any, List, TypedDict
from langchain_core.runnables import RunnableConfig
from tavily import TavilyClient, AsyncTavilyClient
from langgraph.constants import Send
import operator

# Import directly for testing compatibility
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from state import WebSearchState, SearchResult

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def create_fallback_results(query: str, error_message: str) -> List[SearchResult]:
    """
    Create fallback results when search fails.
    
    Args:
        query: The original search query
        error_message: The error message from the failed search
        
    Returns:
        List of fallback SearchResult objects
    """
    error_type = "SearchError"
    
    # Create fallback results with more context
    results = [
        SearchResult(
            title=f"No results found for: {query}",
            url="https://example.com/no-results",
            content=f"The search for '{query}' did not return any results. This could be due to API limitations, connectivity issues, or the query being too specific. Try rephrasing your query or try again later.",
            raw_content=None,
            score=0.5,
            metadata={
                "source": "tavily", 
                "error_type": error_type,
                "error_message": error_message,
                "fallback": True
            }
        )
    ]
    
    # Add a second fallback result with suggestions
    results.append(
        SearchResult(
            title=f"Search suggestions for: {query}",
            url="https://example.com/search-suggestions",
            content=f"Consider trying these related search terms: \n1. {query.replace('2025', '') if '2025' in query else query} latest developments\n2. Recent advances in {query.split()[0] if len(query.split()) > 0 else ''} {query.split()[-1] if len(query.split()) > 1 else ''}\n3. {query} research papers",
            raw_content=None,
            score=0.4,
            metadata={"source": "tavily", "fallback": True}
        )
    )
    
    return results

def parallel_search_execution(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Execute multiple search queries in parallel and aggregate results.
    
    Args:
        state: Current state with search queries
        config: Configuration for the function
        
    Returns:
        Updated state with aggregated search results
    """
    # Get search queries
    search_queries = state.get("search_queries", [])
    
    if not search_queries:
        # If no search queries, use the enhanced query
        enhanced_query = state.get("enhanced_query") or state["query"]
        search_queries = [enhanced_query]
    
    logger.info(f"Executing parallel search for {len(search_queries)} queries")
    
    # Get configuration
    configurable = config.get("configurable", {})
    search_config = configurable.get("search_api", {})
    
    # Execute each search query
    all_results = []
    for query in search_queries:
        logger.info(f"Executing parallel search for query: {query}")
        
        # Create a temporary state for this search
        temp_state = {"search_query": query, "is_parallel": True}
        
        # Execute search
        if search_config.get("provider", "tavily") == "tavily":
            results = execute_tavily_search(query, search_config)
        elif search_config.get("provider") == "google":
            results = execute_google_search(query, search_config)
        elif search_config.get("provider") == "bing":
            results = execute_bing_search(query, search_config)
        else:
            results = execute_tavily_search(query, search_config)
        
        # Add the query to each result's metadata
        for result in results:
            result.metadata["query"] = query
        
        # Add results to all_results
        all_results.extend(results)
    
    # Deduplicate results based on URL
    unique_results = {}
    for result in all_results:
        # Normalize URL for comparison (remove trailing slashes, etc.)
        normalized_url = result.url.rstrip('/')
        if normalized_url not in unique_results or result.score > unique_results[normalized_url].score:
            unique_results[normalized_url] = result
    
    # Convert to list and sort by score
    deduplicated_results = list(unique_results.values())
    sorted_results = sorted(deduplicated_results, key=lambda x: x.score, reverse=True)
    
    # Limit to max_sources from config
    max_sources = configurable.get("max_sources", 4)  # Use the updated default value
    limited_results = sorted_results[:max_sources]
    
    # Return aggregated results
    return {"search_results": limited_results}


class SearchState(TypedDict):
    """State for a single search execution"""
    search_query: str
    is_parallel: bool
    search_results: List[SearchResult]


def execute_search(state: Dict[str, Any], config: RunnableConfig) -> Dict[str, Any]:
    """
    Execute a search for a query using the configured search API.
    
    Args:
        state: Current state with query or search_query
        config: Configuration for the function
        
    Returns:
        Updated state with search results
    """
    # Get configuration
    configurable = config.get("configurable", {})
    search_config = configurable.get("search_api", {})
    
    # Check if this is a parallel search execution
    is_parallel = state.get("is_parallel", False)
    
    # Get query - for parallel execution, use search_query; otherwise use enhanced_query or query
    if is_parallel:
        query = state.get("search_query", "")
        logger.info(f"Executing parallel search for query: {query}")
    else:
        query = state.get("enhanced_query") or state["query"]
        logger.info(f"Executing single search for query: {query}")
    
    # Get search provider
    provider = search_config.get("provider", "tavily")
    
    # Execute search based on provider
    if provider == "tavily":
        results = execute_tavily_search(query, search_config)
    elif provider == "google":
        results = execute_google_search(query, search_config)
    elif provider == "bing":
        results = execute_bing_search(query, search_config)
    else:
        # Default to tavily
        results = execute_tavily_search(query, search_config)
    
    # Add the query to each result's metadata
    for result in results:
        result.metadata["query"] = query
    
    # For parallel execution, return results directly
    # For single execution, deduplicate, sort and limit results
    if is_parallel:
        return {"search_results": results}
    else:
        # Deduplicate results based on URL
        unique_results = {}
        for result in results:
            # Normalize URL for comparison (remove trailing slashes, etc.)
            normalized_url = result.url.rstrip('/')
            if normalized_url not in unique_results or result.score > unique_results[normalized_url].score:
                unique_results[normalized_url] = result
        
        # Convert to list and sort by score
        deduplicated_results = list(unique_results.values())
        sorted_results = sorted(deduplicated_results, key=lambda x: x.score, reverse=True)
        
        # Limit results to max_sources for single search
        max_sources = configurable.get("max_sources", 4)  # Use the updated default value
        limited_results = sorted_results[:max_sources]
        return {"search_results": limited_results}

def execute_tavily_search(query: str, search_config: Dict[str, Any]) -> List[SearchResult]:
    """
    Execute a search using the Tavily API with robust error handling and retries.
    
    Args:
        query: The search query
        search_config: Configuration for the search
        
    Returns:
        List of SearchResult objects
    """
    # Extract configuration
    api_key = search_config.get("api_key") or os.getenv("TAVILY_API_KEY")
    max_results = search_config.get("max_results", 3)
    include_content = search_config.get("include_content", True)
    search_depth = search_config.get("search_depth", "basic")
    include_domains = search_config.get("include_domains", [])
    exclude_domains = search_config.get("exclude_domains", [])
    max_retries = search_config.get("max_retries", 3)
    retry_delay = search_config.get("retry_delay", 1)
    
    # Ensure we have a valid API key
    if not api_key:
        logger.error("No Tavily API key provided")
        return create_fallback_results(query, "No API key provided")
    
    results = []
    
    try:
        # Initialize Tavily client
        client = TavilyClient(api_key=api_key)
        
        # Retry mechanism for API calls
        for attempt in range(max_retries):
            try:
                logger.info(f"Executing Tavily search for query: {query}")
                
                # Execute search with more robust error handling
                try:
                    response = client.search(
                        query=query,
                        max_results=max_results,
                        include_raw_content=include_content
                    )
                    
                    # Verify response is a dictionary
                    if not isinstance(response, dict):
                        logger.error(f"Unexpected response type: {type(response)} for query: {query}")
                        raise ValueError(f"Unexpected response type: {type(response)}")
                    
                    # Process results
                    tavily_results = response.get("results", [])
                    logger.info(f"Got {len(tavily_results)} results from Tavily for query: {query}")
                except Exception as search_error:
                    logger.error(f"Search execution error: {str(search_error)} for query: {query}")
                    raise search_error
                # Convert to SearchResult objects
                for item in tavily_results:
                    result = SearchResult(
                        title=item.get("title", "Untitled"),
                        url=item.get("url", ""),
                        content=item.get("content", ""),  # Using content field for snippet
                        raw_content=item.get("raw_content", None),
                        score=item.get("score", 0.0),
                        metadata={
                            "source": "tavily",
                            "published_date": item.get("published_date", ""),
                            "source_domain": item.get("source", "")
                        }
                    )
                    logger.info(f"Found: {result} results from Tavily for query: {query}")
                    results.append(result)
                
                logger.info(f"Found {len(results)} results from Tavily for query: {query}")
                break  # Success, exit retry loop
                
            except Exception as e:
                if "429" in str(e) and attempt < max_retries - 1:  # Rate limit error and not the last attempt
                    logger.warning(f"Rate limit exceeded. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    # Re-raise if it's not a rate limit error or we've exhausted retries
                    raise
                    
    except Exception as e:
        logger.error(f"Error executing Tavily search: {str(e)}")
        results = create_fallback_results(query, str(e))
    
    return results

def execute_google_search(query: str, search_config: Dict[str, Any]) -> List[SearchResult]:
    """
    Execute a search using Google Search API.
    
    Args:
        query: Search query
        search_config: Search API configuration
        
    Returns:
        List of search results
    """
    # PLACEHOLDER: Actual implementation would call the Google Search API
    max_results = search_config.get("max_results", 5)
    
    # Create placeholder results
    results = [
        SearchResult(
            title=f"Google Result {i+1} for {query}",
            url=f"https://example.com/google{i+1}",
            snippet=f"This is a snippet for Google result {i+1}.",
            content="",
            metadata={"source": "google", "score": 0.9 - (i * 0.1)}
        )
        for i in range(max_results)
    ]
    
    return results

def execute_bing_search(query: str, search_config: Dict[str, Any]) -> List[SearchResult]:
    """
    Execute a search using Bing Search API.
    
    Args:
        query: Search query
        search_config: Search API configuration
        
    Returns:
        List of search results
    """
    # PLACEHOLDER: Actual implementation would call the Bing Search API
    max_results = search_config.get("max_results", 5)
    
    # Create placeholder results
    results = [
        SearchResult(
            title=f"Bing Result {i+1} for {query}",
            url=f"https://example.com/bing{i+1}",
            snippet=f"This is a snippet for Bing result {i+1}.",
            content="",
            metadata={"source": "bing", "score": 0.9 - (i * 0.1)}
        )
        for i in range(max_results)
    ]
    
    return results
