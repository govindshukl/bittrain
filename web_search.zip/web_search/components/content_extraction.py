"""
Content Extraction Component

This component processes content from search results.
"""

from typing import Dict, Any, List
from langchain_core.runnables import RunnableConfig

from state import WebSearchState

def extract_content(state: WebSearchState, config: RunnableConfig) -> Dict[str, Any]:
    """
    Process content from search results.
    
    Args:
        state: Current state with processed results
        config: Configuration for the function
        
    Returns:
        Updated state with processed content
    """
    # Get configuration
    configurable = config.get("configurable", {})
    include_content = configurable.get("include_content", True)
    max_tokens_per_source = configurable.get("max_tokens_per_source", 2000)
    
    # Get processed results
    processed_results = state["processed_results"]
    
    # Skip content processing if disabled
    if not include_content:
        return {"extracted_content": processed_results}
    
    # Process content for each result
    extracted_content = []
    for result in processed_results:
        # Create a copy of the result to modify
        processed_result = result.copy()
        
        # Use raw_content as content if content is not available
        if not processed_result.get("content") and processed_result.get("raw_content"):
            processed_result["content"] = processed_result["raw_content"]
        
        # Ensure we have some content
        if not processed_result.get("content"):
            processed_result["content"] = "No content available for this result."
        
        # Truncate content to max_tokens_per_source if needed
        content = processed_result["content"]
        if content and len(content) > max_tokens_per_source * 4:  # Rough char to token ratio
            processed_result["content"] = content[:max_tokens_per_source * 4] + "..."
        
        # Add to extracted content
        extracted_content.append(processed_result)
    
    # Return updated state
    return {"extracted_content": extracted_content}

# No additional helper functions needed since we're using the content directly from Tavily
