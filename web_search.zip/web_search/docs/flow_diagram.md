flowchart TD
    User([User]) --> |"query: str"| Start([START])
    Start --> ModerateQuery[moderate_query]
    
    ModerateQuery --> |"moderation_result: {is_safe: bool}"| SafetyCheck{Is query safe?}
    
    SafetyCheck --> |No| End([END])
    SafetyCheck --> |Yes| EnhanceQuery[enhance_query]
    
    EnhanceQuery --> |"enhanced_query: str, search_queries: List[str]"| ParallelCheck{Multiple queries?}
    
    ParallelCheck --> |No| ExecuteSearch[execute_search]
    ParallelCheck --> |Yes| ParallelSearches[parallel_search_execution]
    
    ParallelSearches --> |"Send()"| ExecuteSearch
    
    ExecuteSearch --> |"search_results: List[SearchResult]"| ProcessResults[process_results]
    
    ProcessResults --> |"processed_results: List[Dict]"| ExtractContent[extract_content]
    
    ExtractContent --> |"extracted_content: List[Dict]"| GenerateResponse[generate_response]
    
    GenerateResponse --> |"response: str"| FormatSources[format_sources]
    
    FormatSources --> |"sources: List[Dict]"| End
    
    End --> |"response: str, sources: List[Dict]"| User
    
    subgraph "State Transformations"
        ModerateQuery --> |Updates| State1["WebSearchState
        {query, moderation_result}"]
        
        EnhanceQuery --> |Updates| State2["WebSearchState
        {query, moderation_result, enhanced_query, search_queries}"]
        
        ParallelSearches --> |Creates| ParallelState["Multiple parallel states with
        {search_query: str} for each query"]
        
        ExecuteSearch --> |Updates| State3["WebSearchState
        {query, moderation_result, enhanced_query, search_queries, search_results}
        search_results contains aggregated results from all queries:
        List[SearchResult] where each result has:
          * title: str (title of the page)
          * content: str (snippet/summary)
          * raw_content: str or None (full content)
          * url: str (page URL)
          * score: float (relevance score 0.0-1.0)
          * query: str (the query that produced this result)
        - follow_up_questions: Optional[List[str]]
        - response_time: float
        - images: List[Dict]
        - answer: Optional[str]"]
        
        ProcessResults --> |Updates| State4["WebSearchState
        {query, moderation_result, enhanced_query, search_results, processed_results}"]
        
        ExtractContent --> |Updates| State5["WebSearchState
        {query, moderation_result, enhanced_query, search_results, processed_results, extracted_content}"]
        
        GenerateResponse --> |Updates| State6["WebSearchState
        {query, moderation_result, enhanced_query, search_results, processed_results, extracted_content, response}"]
        
        FormatSources --> |Updates| State7["WebSearchState
        {query, moderation_result, enhanced_query, search_results, processed_results, extracted_content, response, sources}"]
    end
    
    subgraph "External Services"
        LLM[["Language Models (LLM)"]]
        TavilyAPI[["Tavily Search API"]]
        WebContent[["Web Content Extraction"]]
        
        ModerateQuery -.-> LLM
        EnhanceQuery -.-> LLM
        ExecuteSearch -.-> TavilyAPI
        ExtractContent -.-> WebContent
        GenerateResponse -.-> LLM
    end
