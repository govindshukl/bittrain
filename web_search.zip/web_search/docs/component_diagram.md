```mermaid
classDiagram
    class WebSearchState {
        +str query
        +str enhanced_query
        +Dict moderation_result
        +List~SearchResult~ search_results
        +List~Dict~ processed_results
        +List~Dict~ extracted_content
        +str response
        +List~Dict~ sources
    }
    
    class SearchResult {
        +str title        // Title of the search result
        +str url          // URL of the search result
        +str content      // Summary/snippet of the content
        +str raw_content  // Full content (may be None)
        +float score      // Relevance score (0.0-1.0)
        +Dict metadata    // Additional metadata
    }
    
    class TavilyResponse {
        +str query
        +List~SearchResult~ results
        +List~str~ follow_up_questions
        +str answer
        +List~Dict~ images
        +float response_time
    }
    
    class WebSearchConfig {
        +int max_search_queries
        +int max_sources
        +bool include_content
        +LLMConfig llm
        +SearchAPIConfig search_api
        +ModerationConfig moderation
        +int timeout
        +int max_retries
        +int max_tokens_per_source
        +bool summarize_sources
        +get_runnable_config()
    }
    
    class MainGraph {
        +StateGraph graph
        +create_web_search_graph()
        +run_web_search()
    }
    
    class ContentModeration {
        +moderate_query(state, config)
    }
    
    class QueryEnhancement {
        +enhance_query(state, config)
    }
    
    class SearchExecution {
        +execute_search(state, config)
        +parallel_search_execution(state)
        -execute_tavily_search(query, config)
        -execute_google_search(query, config)
        -execute_bing_search(query, config)
    }
    
    class ResultProcessing {
        +process_results(state, config)
    }
    
    class ContentExtraction {
        +extract_content(state, config)
        -fetch_and_extract_content(url)
    }
    
    class ResponseGeneration {
        +generate_response(state, config)
    }
    
    class SourceFormatting {
        +format_sources(state, config)
    }
    
    MainGraph --> WebSearchState : uses
    MainGraph --> WebSearchConfig : uses
    MainGraph --> ContentModeration : calls
    MainGraph --> QueryEnhancement : calls
    MainGraph --> SearchExecution : calls
    MainGraph --> ResultProcessing : calls
    MainGraph --> ContentExtraction : calls
    MainGraph --> ResponseGeneration : calls
    MainGraph --> SourceFormatting : calls
    
    ContentModeration --> WebSearchState : updates
    QueryEnhancement --> WebSearchState : updates
    SearchExecution --> WebSearchState : updates
    ResultProcessing --> WebSearchState : updates
    ContentExtraction --> WebSearchState : updates
    ResponseGeneration --> WebSearchState : updates
    SourceFormatting --> WebSearchState : updates
    
    WebSearchState --> SearchResult : contains
```
