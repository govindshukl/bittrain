sequenceDiagram
    participant User
    participant MainGraph as StateGraph(WebSearchState)
    participant LLM as Language Models
    participant TavilyAPI as Tavily Search API
    participant WebContent as Web Content Extraction

    User->>MainGraph: Input Query
    Note over MainGraph: START

    MainGraph->>MainGraph: moderate_query
    activate MainGraph
    MainGraph->>LLM: Check query for inappropriate content
    LLM-->>MainGraph: Return moderation result
    deactivate MainGraph

    alt Query is safe
        MainGraph->>MainGraph: enhance_query
        activate MainGraph
        MainGraph->>LLM: Optimize query and generate multiple search queries
        LLM-->>MainGraph: Return enhanced query and search queries
        deactivate MainGraph
        
        alt Multiple search queries
            MainGraph->>MainGraph: parallel_search_execution
            activate MainGraph
            Note right of MainGraph: Create parallel tasks for each search query
            loop For each search query
                MainGraph-->>MainGraph: Send("execute_search", {search_query})
            end
            deactivate MainGraph
        else Single query
            MainGraph->>MainGraph: execute_search
        end
        
        MainGraph->>MainGraph: execute_search
        activate MainGraph
        MainGraph->>TavilyAPI: Send search request with parameters
        Note right of TavilyAPI: Parameters include:
        Note right of TavilyAPI: - query
        Note right of TavilyAPI: - include_domains
        Note right of TavilyAPI: - exclude_domains
        Note right of TavilyAPI: - max_results
        Note right of TavilyAPI: - include_raw_content
        Note right of TavilyAPI: - topic (general/news)
        Note right of TavilyAPI: - days (for news)
        TavilyAPI-->>MainGraph: Return TavilyResponse
        Note left of TavilyAPI: Response includes:
        Note left of TavilyAPI: - results array with each result containing:
        Note left of TavilyAPI:   * title (str)
        Note left of TavilyAPI:   * content (str)
        Note left of TavilyAPI:   * raw_content (str or None)
        Note left of TavilyAPI:   * url (str)
        Note left of TavilyAPI:   * score (float) - relevance score
        Note left of TavilyAPI: - follow_up_questions (None or array)
        Note left of TavilyAPI: - response_time (float)
        Note left of TavilyAPI: - images (array)
        deactivate MainGraph

        MainGraph->>MainGraph: process_results
        activate MainGraph
        MainGraph->>MainGraph: Remove duplicates
        MainGraph->>MainGraph: Sort by relevance score
        MainGraph->>MainGraph: Limit to max_sources
        deactivate MainGraph

        MainGraph->>MainGraph: extract_content
        activate MainGraph
        MainGraph->>MainGraph: Process raw_content from Tavily
        MainGraph->>WebContent: Fetch additional content if needed
        WebContent-->>MainGraph: Return extracted content
        MainGraph->>MainGraph: Clean and format content
        deactivate MainGraph

        MainGraph->>MainGraph: generate_response
        activate MainGraph
        MainGraph->>LLM: Generate comprehensive response
        LLM-->>MainGraph: Return generated response
        deactivate MainGraph

        MainGraph->>MainGraph: format_sources
        activate MainGraph
        MainGraph->>MainGraph: Format source citations
        deactivate MainGraph

        MainGraph-->>User: Return response with sources
    else Query is unsafe
        MainGraph-->>User: Return moderation warning
    end

    Note over MainGraph: END
