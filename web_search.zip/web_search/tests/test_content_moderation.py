import sys
import os
import asyncio
from dotenv import load_dotenv

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary modules
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Now we can import our modules
from state import WebSearchState
from config import WebSearchConfig

# Import the function to test with a direct import
from components.content_moderation import moderate_query

# Load environment variables
load_dotenv()

async def test_moderation():
    """Test the content moderation component with different queries."""
    # Create test config
    config = WebSearchConfig()
    runnable_config = config.get_runnable_config()
    
    # Test cases - safe and potentially unsafe queries
    test_cases = [
        {"query": "What is the weather today?", "expected_safe": True},
        {"query": "How to make a cake recipe", "expected_safe": True},
        {"query": "How to hack into someone's account", "expected_safe": False},
    ]
    
    # Run tests
    for test in test_cases:
        # Create state with query
        state = {"query": test["query"]}
        
        # Call moderation function
        result = moderate_query(state, runnable_config)
        
        # Print results
        print(f"\nQuery: {test['query']}")
        print(f"Expected safe: {test['expected_safe']}")
        print(f"Result: {result['moderation_result']}")
        print(f"Matches expectation: {result['moderation_result']['is_safe'] == test['expected_safe']}")

if __name__ == "__main__":
    asyncio.run(test_moderation())
