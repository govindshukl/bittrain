import sys
import os
import asyncio
from dotenv import load_dotenv

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary modules
from components.search_execution import execute_search, parallel_search_execution
from state import WebSearchState, SearchResult
from langchain_core.runnables import RunnableConfig

# Load environment variables
load_dotenv()

def test_single_search():
    """
    Test the search execution component with a single query.
    """
    # Create state
    state = WebSearchState(
        query="climate change solutions",
        enhanced_query="effective climate change solutions 2025",
        search_queries=[],
        moderation_result={"is_safe": True},
        search_results=[],
        processed_results=[],
        extracted_content=[],
        response="",
        sources=[]
    )
    
    # Create runnable config
    runnable_config = RunnableConfig(
        configurable={
            "search_api": {
                "provider": "tavily",
                "max_results": 3,
                "include_content": True
            }
        }
    )
    
    # Call execute_search
    print("\n--- Testing Single Search Execution ---")
    result = execute_search(state, runnable_config)
    
    # Get search results
    search_results = result.get("search_results", [])
    
    # Print results
    print(f"Found {len(search_results)} results")
    for i, result in enumerate(search_results):
        print(f"  {i+1}. {result.title} - {result.url}")
        print(f"     Score: {result.score}")
        print(f"     Query: {result.metadata.get('query', 'N/A')}")
        print()

def test_parallel_search():
    """
    Test the parallel search execution component with multiple queries.
    """
    # Create state with multiple search queries
    state = WebSearchState(
        query="renewable energy",
        enhanced_query="renewable energy technologies 2025",
        search_queries=[
            "latest solar energy advancements 2025",
            "wind power technology innovations",
            "geothermal energy developments May 2025"
        ],
        moderation_result={"is_safe": True},
        search_results=[],
        processed_results=[],
        extracted_content=[],
        response="",
        sources=[]
    )
    
    # Create runnable config
    runnable_config = RunnableConfig(
        configurable={
            "search_api": {
                "provider": "tavily",
                "max_results": 2,
                "include_content": True
            }
        }
    )
    
    # Call parallel_search_execution with config
    print("\n--- Testing Parallel Search Execution ---")
    result = parallel_search_execution(state, runnable_config)
    
    # Get search results
    search_results = result.get("search_results", [])
    print(f"Found {len(search_results)} aggregated results from parallel search")
    
    # Print results by query
    query_results = {}
    for res in search_results:
        query = res.metadata.get('query', 'Unknown')
        if query not in query_results:
            query_results[query] = []
        query_results[query].append(res)
    
    # Print results for each query
    for i, (query, results) in enumerate(query_results.items()):
        print(f"\nResults for query {i+1}: {query}")
        print(f"Found {len(results)} results")
        
        for j, res in enumerate(results):
            print(f"  {j+1}. {res.title} - {res.url}")
            print(f"     Score: {res.score}")
    
    # Print top 5 results
    print("\nTop 5 results across all queries:")
    for i, res in enumerate(search_results[:5]):
        print(f"  {i+1}. {res.title} - {res.url}")
        print(f"     Score: {res.score}")
        print(f"     Query: {res.metadata.get('query', 'N/A')}")

if __name__ == "__main__":
    test_single_search()
    test_parallel_search()
