import sys
import os
import asyncio
from dotenv import load_dotenv

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary modules
from main import run_web_search
from config import WebSearchConfig
from components.search_execution import execute_tavily_search

# Load environment variables
load_dotenv()

async def test_ai_search():
    """
    Test AI-related search queries directly with Tavily API and through the web search pipeline.
    """
    print("\n" + "="*80)
    print("Testing AI-related search queries")
    print("="*80)
    
    # Test queries
    ai_queries = [
        "Recent advancements in artificial intelligence May 2025",
        "New AI technologies and innovations 2025",
        "Current trends in AI research and applications 2025"
    ]
    
    # Test direct Tavily API calls
    print("\n--- Testing Direct Tavily API Calls ---")
    search_config = {
        "max_results": 3,
        "include_content": True
    }
    
    for query in ai_queries:
        print(f"\nQuery: {query}")
        results = execute_tavily_search(query, search_config)
        print(f"Found {len(results)} results")
        
        for i, result in enumerate(results):
            print(f"  {i+1}. {result.title} - {result.url}")
            print(f"     Score: {result.score}")
    
    # Test through web search pipeline
    print("\n--- Testing Through Web Search Pipeline ---")
    for query in ai_queries:
        print(f"\nQuery: {query}")
        
        # Create config with specified max_search_queries
        config = {
            "max_search_queries": 1,  # Single query
            "search_api": {
                "max_results": 3,
                "include_content": True
            }
        }
        
        # Run the search
        result = await run_web_search(query, config)
        
        # Print the result
        print(f"Response: {result['response'][:100]}...")
        print(f"Total sources: {len(result['sources'])}")
        
        for i, source in enumerate(result["sources"]):
            print(f"  {i+1}. {source.get('title', 'Untitled')}: {source.get('url', 'No URL')}")

if __name__ == "__main__":
    asyncio.run(test_ai_search())
