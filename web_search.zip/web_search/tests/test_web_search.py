import sys
import os
import asyncio
from dotenv import load_dotenv

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary modules
from main import run_web_search
from config import WebSearchConfig

# Load environment variables
load_dotenv()

async def test_web_search():
    """
    Test the complete web search system.
    """
    # Test cases
    test_cases = [
        {
            "query": "renewable energy technologies",
            "max_search_queries": 1,  # Single query
            "description": "Single query search"
        },
        {
            "query": "latest AI developments",
            "max_search_queries": 3,  # Multiple queries
            "description": "Multiple query search with parallel execution"
        }
    ]
    
    # Test each case
    for case in test_cases:
        query = case["query"]
        max_search_queries = case["max_search_queries"]
        description = case["description"]
        
        print(f"\n{'='*80}")
        print(f"Testing: {description}")
        print(f"Query: {query}")
        print(f"Max search queries: {max_search_queries}")
        print(f"{'='*80}")
        
        # Create config with specified max_search_queries
        config = {
            "max_search_queries": max_search_queries,
            "search_api": {
                "max_results": 3,
                "include_content": True
            }
        }
        
        # Run the search
        result = await run_web_search(query, config)
        
        # Print the result
        print("\nResponse:")
        print("-" * 40)
        print(result["response"])
        print("\nSources:")
        print("-" * 40)
        for i, source in enumerate(result["sources"]):
            print(f"{i+1}. {source.get('title', 'Untitled')}: {source.get('url', 'No URL')}")
        
        print(f"\nTotal sources: {len(result['sources'])}")
        print(f"{'='*80}")

if __name__ == "__main__":
    asyncio.run(test_web_search())
