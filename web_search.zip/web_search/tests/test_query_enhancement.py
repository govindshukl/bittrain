import sys
import os
import asyncio
from dotenv import load_dotenv

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the necessary modules
from components.query_enhancement import enhance_query
from state import WebSearchState
from langchain_core.runnables import RunnableConfig

# Load environment variables
load_dotenv()

def test_enhance_query():
    """
    Test the query enhancement component with both single and multiple query generation.
    """
    # Test cases
    test_cases = [
        {
            "query": "weather today",
            "expected_enhancement": True,  # We expect some enhancement
            "max_search_queries": 1,  # Single query
            "time_sensitive": True  # Should include date/time references
        },
        {
            "query": "best programming language",
            "expected_enhancement": True,
            "max_search_queries": 3,  # Multiple queries
            "time_sensitive": False  # General query, may not need time references
        },
        {
            "query": "latest AI developments",
            "expected_enhancement": True,
            "max_search_queries": 2,  # Multiple queries
            "time_sensitive": True  # Should include date/time references
        },
        {
            "query": "recent news about climate change",
            "expected_enhancement": True,
            "max_search_queries": 3,  # Multiple queries
            "time_sensitive": True  # Should include date/time references
        }
    ]
    
    # Test each case
    for case in test_cases:
        query = case["query"]
        max_search_queries = case["max_search_queries"]
        
        # Create runnable config
        runnable_config = RunnableConfig(
            configurable={
                "llm": {
                    "model": "gpt-4o",
                    "temperature": 0.2
                },
                "max_search_queries": max_search_queries
            }
        )
        
        # Create state
        state = WebSearchState(
            query=query,
            enhanced_query="",
            search_queries=[],
            moderation_result={},
            search_results=[],
            processed_results=[],
            extracted_content=[],
            response="",
            sources=[]
        )
        
        # Call enhance_query
        result = enhance_query(state, runnable_config)
        
        # Get enhanced query and search queries
        enhanced_query = result["enhanced_query"]
        search_queries = result["search_queries"]
        
        # Print results
        print(f"\n--- Test with max_search_queries={max_search_queries} ---")
        print(f"Original Query: {query}")
        print(f"Primary Enhanced Query: {enhanced_query}")
        print(f"Generated {len(search_queries)} search queries:")
        for i, q in enumerate(search_queries):
            print(f"  {i+1}. {q}")
        
        # Check if enhancement happened
        if case["expected_enhancement"]:
            print(f"Enhancement occurred: {enhanced_query != query}")
        
        # Check if we got the expected number of queries
        print(f"Expected queries: {max_search_queries}, Got: {len(search_queries)}")
        print(f"All queries are unique: {len(set(search_queries)) == len(search_queries)}")
        
        # Check for time references if the query is time-sensitive
        if case.get("time_sensitive", False):
            # Get current year and month
            import datetime
            current_year = str(datetime.datetime.now().year)
            current_month = datetime.datetime.now().strftime("%B")
            
            # Look for time references in the queries
            time_references = []
            for q in search_queries:
                if current_year in q or current_month in q or "today" in q.lower() or "latest" in q.lower() or "recent" in q.lower() or "current" in q.lower():
                    time_references.append(q)
            
            print(f"Time references found: {len(time_references)} out of {len(search_queries)}")
            if time_references:
                print("Queries with time references:")
                for i, q in enumerate(time_references):
                    print(f"  {i+1}. {q}")
        
        print("-" * 50)

if __name__ == "__main__":
    test_enhance_query()
