# Web Search with LangGraph

A modular web search system built using LangGraph that performs intelligent search, content extraction, and response generation.

## Project Structure

```
/web_search/
├── main.py                      # Main entry point and graph definition
├── state.py                     # State definitions and models
├── config.py                    # Configuration parameters
└── components/                  # Individual components as separate files
    ├── query_enhancement.py     # Enhances user queries
    ├── content_moderation.py    # Checks for inappropriate content
    ├── search_execution.py      # Executes search via different providers
    ├── result_processing.py     # Processes and ranks search results
    ├── content_extraction.py    # Extracts full content from URLs
    ├── response_generation.py   # Generates responses from content
    └── source_formatting.py     # Formats source citations
```

## Features

- Query enhancement using LLMs
- Content moderation for safe searching
- Multiple search provider support (Tavily, Google, Bing)
- Result processing and ranking
- Full content extraction from web pages
- Comprehensive response generation
- Source citation and formatting

## Installation

1. Clone this repository
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Set up environment variables (see `.env.example`)

## Usage

```python
import asyncio
from main import run_web_search

async def main():
    result = await run_web_search("Your search query here")
    print(result["response"])

asyncio.run(main())
```

## Configuration

See `config.py` for all available configuration options.
