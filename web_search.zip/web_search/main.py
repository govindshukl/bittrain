import asyncio
import os
from typing import Dict, Any, List
from dotenv import load_dotenv

from langgraph.graph import StateGraph, START, END
from langgraph.constants import Send

# Import components
from state import WebSearchState, WebSearchInput, WebSearchOutput
from config import WebSearchConfig
from components.query_enhancement import enhance_query
from components.content_moderation import moderate_query
from components.search_execution import execute_search, parallel_search_execution
from components.result_processing import process_results
from components.content_extraction import extract_content
from components.response_generation import generate_response
from components.source_formatting import format_sources
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

def create_web_search_graph() -> StateGraph:
    """
    Create the web search graph with all components.
    
    Returns:
        StateGraph: The compiled web search graph
    """
    # Create a new graph
    builder = StateGraph(WebSearchState)
    
    # Add nodes
    builder.add_node("moderate_query", moderate_query)
    builder.add_node("enhance_query", enhance_query)
    builder.add_node("parallel_search_execution", parallel_search_execution)
    builder.add_node("execute_search", execute_search)
    builder.add_node("process_results", process_results)
    builder.add_node("extract_content", extract_content)
    builder.add_node("generate_response", generate_response)
    builder.add_node("format_sources", format_sources)
    
    # Add edges
    builder.add_edge(START, "moderate_query")
    
    # Conditional edge based on moderation result
    builder.add_conditional_edges(
        "moderate_query",
        lambda state: "enhance_query" if state["moderation_result"]["is_safe"] else END
    )
    
    # Conditional edge based on whether we have multiple search queries
    def should_use_parallel_search(state):
        search_queries = state.get("search_queries", [])
        if len(search_queries) > 1:
            logger.info(f"Using parallel search execution for {len(search_queries)} queries")
            return "parallel_search_execution"
        else:
            logger.info("Using single search execution")
            return "execute_search"
    
    # After enhancing the query, decide whether to use parallel search
    builder.add_conditional_edges(
        "enhance_query",
        should_use_parallel_search,
        ["parallel_search_execution", "execute_search"]
    )
    
    # Add edge from parallel search to process results
    builder.add_edge("parallel_search_execution", "process_results")
    
    builder.add_edge("execute_search", "process_results")
    builder.add_edge("process_results", "extract_content")
    builder.add_edge("extract_content", "generate_response")
    builder.add_edge("generate_response", "format_sources")
    builder.add_edge("format_sources", END)
    
    # Compile the graph
    return builder.compile()

async def run_web_search(query: str, config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Run the web search graph with a query.
    
    Args:
        query (str): The search query
        config (Dict[str, Any], optional): Configuration overrides
        
    Returns:
        Dict[str, Any]: The search results
    """
    # Create search config
    search_config = WebSearchConfig()
    if config:
        for key, value in config.items():
            if hasattr(search_config, key):
                setattr(search_config, key, value)
    
    # Create search graph
    search_graph = create_web_search_graph()
    
    # Create initial state
    initial_state = {
        "query": query,
        "enhanced_query": "",
        "search_queries": [],
        "moderation_result": {},
        "search_results": [],
        "processed_results": [],
        "extracted_content": [],
        "response": "",
        "sources": []
    }
    
    # Run the search graph
    result = await search_graph.ainvoke(
        initial_state,
        config=search_config.get_runnable_config()
    )
    
    return result

if __name__ == "__main__":
    import argparse
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Web Search")
    parser.add_argument("query", type=str, help="Search query")
    args = parser.parse_args()
    
    # Run the search
    result = asyncio.run(run_web_search(args.query))
    
    # Print the result
    print("\n" + "="*80)
    print(f"Search Results for: {args.query}")
    print("="*80)
    print(result["response"])
    print("\nSources:")
    for source in result["sources"]:
        print(f"- {source['title']}: {source['url']}")
    print("="*80)
