#!/usr/bin/env python
"""
Web Search CLI Tool

This script provides a command-line interface for the web search system.
It allows users to enter a query and get search results.
"""

import os
import sys
import asyncio
import argparse
from dotenv import load_dotenv
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import the necessary modules
from main import run_web_search
from config import WebSearchConfig

# Load environment variables
load_dotenv()

# Initialize rich console
console = Console()

async def search_with_progress(query, config=None):
    """
    Execute a web search with a progress indicator.
    
    Args:
        query: The search query
        config: Optional configuration overrides
        
    Returns:
        The search results
    """
    with Progress() as progress:
        task = progress.add_task("[cyan]Searching...", total=None)
        
        # Run the search
        result = await run_web_search(query, config)
        
        progress.update(task, completed=100)
        
    return result

def format_sources(sources):
    """
    Format sources for display.
    
    Args:
        sources: List of source dictionaries
        
    Returns:
        Formatted string of sources
    """
    if not sources:
        return "No sources found."
    
    result = []
    for i, source in enumerate(sources):
        result.append(f"{i+1}. [{source.get('title', 'Untitled')}]({source.get('url', 'No URL')})")
    
    return "\n".join(result)

async def main():
    """Main function to run the CLI."""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Web Search CLI")
    parser.add_argument("--query", "-q", type=str, help="Search query")
    parser.add_argument("--max-queries", "-m", type=int, default=2, 
                        help="Maximum number of search queries (1 for single, >1 for parallel)")
    parser.add_argument("--max-results", "-r", type=int, default=3,
                        help="Maximum number of results per query")
    parser.add_argument("--max-sources", "-s", type=int, default=4,
                        help="Maximum number of sources in the final result")
    parser.add_argument("--no-moderation", action="store_true", 
                        help="Disable content moderation")
    args = parser.parse_args()
    
    # Get query from command line or prompt
    query = args.query
    if not query:
        query = console.input("[bold green]Enter your search query:[/] ")
    
    # Create config
    config = {
        "max_search_queries": args.max_queries,
        "max_sources": args.max_sources,
        "search_api": {
            "max_results": args.max_results,
            "include_content": True
        },
        "moderation": {
            "enabled": not args.no_moderation
        }
    }
    
    # Print query info
    console.print(f"\n[bold]Searching for:[/] {query}")
    console.print(f"[bold]Max search queries:[/] {args.max_queries}")
    console.print(f"[bold]Max results per query:[/] {args.max_results}")
    console.print(f"[bold]Max sources in final result:[/] {args.max_sources}")
    console.print(f"[bold]Content moderation:[/] {'Disabled' if args.no_moderation else 'Enabled'}\n")
    
    # Execute search
    result = await search_with_progress(query, config)
    
    # Print response - clean up any formatting issues
    response_text = result["response"]
    
    # Remove any header formatting that was added by the fallback response
    if response_text.startswith("# Information about") or response_text.startswith("┏━━━"):
        # This is likely a fallback response with formatting - extract just the content
        try:
            # Try to extract just the content part
            content_parts = response_text.split("\n\n", 2)
            if len(content_parts) > 2:
                response_text = content_parts[2]
        except Exception:
            # If extraction fails, use the original text
            pass
    
    # Remove any sources section that might have been included by the LLM
    if "\n## Sources" in response_text:
        response_text = response_text.split("\n## Sources")[0].strip()
    elif "\nSources:" in response_text:
        response_text = response_text.split("\nSources:")[0].strip()
    elif "\n**Sources**" in response_text:
        response_text = response_text.split("\n**Sources**")[0].strip()
    
    # Print the response in a clean panel
    console.print(Panel(Markdown(response_text), title="Response", border_style="green"))
    
    # Print sources in a separate panel
    sources_md = format_sources(result["sources"])
    console.print(Panel(Markdown(sources_md), title=f"Sources ({len(result['sources'])})", border_style="blue"))

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[bold red]Search canceled.[/]")
        sys.exit(0)
