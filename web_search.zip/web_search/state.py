from typing import List, Dict, Any, TypedDict, Annotated, Optional
import operator
from pydantic import BaseModel, Field

class SearchResult(BaseModel):
    """Search result model"""
    title: str = Field(description="Title of the search result")
    url: str = Field(description="URL of the search result")
    content: str = Field(description="Summary/snippet of the content")
    raw_content: Optional[str] = Field(None, description="Full content if available")
    score: float = Field(0.0, description="Relevance score (0.0-1.0)")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")

class WebSearchInput(TypedDict):
    """Input state for the web search graph"""
    query: str  # Original user query

class WebSearchOutput(TypedDict):
    """Output state for the web search graph"""
    response: str  # Final response to user
    sources: List[Dict[str, Any]]  # Sources used in the response

class WebSearchState(TypedDict):
    """State for the web search graph"""
    query: str  # Original user query
    enhanced_query: str  # Enhanced query after processing
    search_queries: List[str]  # Multiple search queries for better coverage
    moderation_result: Dict[str, Any]  # Result of content moderation
    search_results: List[SearchResult]  # Results from search API
    processed_results: List[Dict[str, Any]]  # Processed and ranked sources
    extracted_content: List[Dict[str, Any]]  # Extracted content from sources
    response: str  # Final response
    sources: List[Dict[str, Any]]  # Sources used in the response
